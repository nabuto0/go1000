const help = (prefix) => {
	return `
*BOT NABUTO 2.0*

┏━━❉ *Abour User* ❉━━━┓
┣⊱ *nama* : ${pushname}
┣⊱ *nomer* : wa.me/${sender.split("@")[0]}
┣⊱ *XP* : ${getLevelingXp(sender)}/${reqXp}
┣⊱ *level* : ${getLevelingLevel(sender)}
┗━━━━━━━━━━━━━━━━


OQ VEIO NESTA ATUALIZAÇÃO?!
-COMANDOS ARRUMADOS
-PING
-NOVOS COMANDOS

PARA SABER MAIS DIGITE:  ${prefix}info
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
  *comandos básicos*
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}sticker
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}toimg
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}play
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}ytmp4
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}wame
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}tts pt 
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}meme
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}nabutojokes
━━━━━━━━━❮◆❯━━━━━━━━━

▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
    *IMAGEM ANIME*
▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
 ${prefix}loli
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}randomanime
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}loli
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}pokemon
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}naruto
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}hinata
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}sakura
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}boruto
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}quotesnime
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}wait
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}nekoanime
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}neko
━━━━━━━━━❮◆❯━━━━━━━━━
▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
        *+18*
▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
 ${prefix}packporn
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}porno
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}hentai
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}randomhentai
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}packdrive
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}randombokep 
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}nsfwtrap
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}nekopoi
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}nekopoi
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}xvideos
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}pornhub
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
  𝗗𝗜𝗩𝗘𝗥𝗦𝗔̃𝗢/𝗜𝗡𝗧𝗘𝗥𝗔𝗚𝗜𝗥*
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}meme
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}nabutojokes
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}simih [1/0]
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
  𝗠𝗘𝗡𝗨 𝗣𝗔𝗥𝗔 𝗚𝗥𝗨𝗣𝗢𝗦
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟ 
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}leveling [on/off]
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}linkgp
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}abrirgp
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}fechargp
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}hidetag
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}marcar
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}adms
━━━━━━━━━❮◆❯━━━━━━━━━
 *${prefix}antilink* [1/0]
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}simih [1/0]
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}setfoto
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}setname
━━━━━━━━━❮◆❯━━━━━━━━━
${prefix}grupoinfo
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}banir
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}bemvindo [1/0]
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}promover
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}rebaixar
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}meme
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
  PUXAR DADOS/TESTE
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}cep
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}cpf
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}ip
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}placa
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}bin
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
  𝗔𝗣𝗘𝗡𝗔𝗦 𝗣𝗔𝗥𝗔 𝗢 𝗗𝗢𝗡𝗢
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
 ${prefix}bc
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}bcgp
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}off
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}block
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}unblock
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}setnomebot
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
       𝗢𝗨𝗧𝗥𝗢𝗦
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}map
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}ttp
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}attp
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}tts pt
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}tomp3
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}modonsfw on/off
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}modoanime on/off
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}animecry
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}destrava
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}premiumlist
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}modapk
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
       𝗠𝗔𝗜𝗦 𝗔𝗟𝗚𝗨𝗡𝗦
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}level
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}moddroid
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}happymod
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}pronomeneu
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}brainly
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
     𝗕𝗥𝗜𝗡𝗖𝗔𝗗𝗘𝗜𝗥𝗔𝗦
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}gado
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}corno
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}namorar
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}gay
━━━━━━━━━❮◆❯━━━━━━━━━
 ▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜
      LOGOS/IMAGENS
 ▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟

📌 ATENÇÃO 📌
ESTE MENU AINDA ESTÁ EM TESTE, SE NÃO ESTIVER FUNCIONANDO NA PRÓXIMA ATUALIZAÇÃO EU ARRUMO.
AS ATUALIZAÇÕES VOCÊ PODE CONFIRMAR NO CANAL: https://youtube.com/channel/UCZEtf9AlsC2zsJQwrfW-44w
👇
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}bpink <texto>
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}quotemaker <texto>
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}snowwrite <texto|texto>
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}3dtext <texto>
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}firetext <texto>
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}glitch <texto|texto>
━━━━━━━━━❮◆❯━━━━━━━━━
 ${prefix}metalictglow <texto>

𝗙𝗜𝗠 𝗗𝗢 𝗠𝗘𝗡𝗨



Olá, quer ficar por dentro de todas atualizações do bot? ou quer contratar o bot ou tirar um dúvida? me chame no privado: wa.me/556993733829

📌REGRAS NO MEU PV:

❌NÃO FLODE

❌NÃO ME LIGUE

❌TRAVAS = PUNIÇÃO DESATIVANDO




`
}

exports.help = help

















